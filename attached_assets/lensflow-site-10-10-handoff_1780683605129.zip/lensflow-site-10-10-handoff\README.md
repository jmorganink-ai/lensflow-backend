# LensFlow 10/10 Website Handoff

Frontend-only replacement files for the LensFlow marketing website.

Copy these files into the same paths in the full website project:

- `src/pages/Home.tsx`
- `src/components/layout/Navbar.tsx`
- `src/components/layout/Footer.tsx`
- `src/components/SubmitForm.tsx`

What changed:

- Homepage now opens with "Create Luxury Property Campaigns in Minutes".
- The first action is "Generate Property Campaign".
- Mia and Oliver are visible as a core product feature.
- Campaign outputs, marketing value and pricing are shown before internal/product detail.
- Navigation is focused on examples, presenters, workflow, value and pricing.
- Visible copy in the changed files is ASCII-clean to avoid encoding issues in Windows/Replit previews.

No backend files, API routes, authentication, upload logic or subscription logic were changed.
