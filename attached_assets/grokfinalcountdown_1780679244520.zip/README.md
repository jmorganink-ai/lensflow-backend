# LensFlow Backend

Complete "URL → Video" pipeline.

## Setup
1. `npm install`
2. Copy `.env.example` to `.env` and fill keys
3. `node test-runner.js "https://www.domain.com.au/..."`

Ready for Railway / Render deployment.