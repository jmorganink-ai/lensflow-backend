# LensFlow Dashboard Upgrade Pack for Replit

## What this pack is for

This pack is for upgrading the **look of the LensFlow dashboard only**.

Do **not** rebuild the app.
Do **not** touch the backend.
Do **not** touch the real video pipeline.
Do **not** touch authentication, database, billing, Stripe, HeyGen, OpenAI, ElevenLabs, Shotstack, or job creation logic.

The goal is cosmetic/UI improvement only.

---

## Files included

### 1. `dashboard_v1_safe_cosmetic.tsx`
Safest version. Use this first.

It keeps closer to the original `dashboard.tsx` and mainly changes:
- dashboard heading
- hero campaign section
- stat labels
- Recent Jobs → Recent Campaigns
- moves Market Brief lower
- keeps original dashboard logic intact

### 2. `dashboard_v2_premium_cosmetic.tsx`
More premium version. Use this after testing V1.

It adds:
- stronger premium hero
- quick launch panel
- presenter studio card
- marketing value card
- stronger LensFlow SaaS feel
- all 4 presenters: Mia, Oliver, Liam, Sophie

### 3. `lensflow_dashboard_preview.html`
Simple browser preview only.

This is **not production code**. It is only to visually understand the direction.

---

## Recommended implementation order

1. Backup the current `dashboard.tsx`.
2. Test `dashboard_v1_safe_cosmetic.tsx` first.
3. If it compiles and looks correct, test `dashboard_v2_premium_cosmetic.tsx`.
4. Do not publish until the preview looks correct in Replit.
5. Keep all existing route/API/backend logic untouched.

---

## Main product direction

The dashboard should feel like:

**Luxury Real Estate Marketing Operating System**

Not:

**Internal admin panel**

The first thing an agent sees should be:

**Generate Property Campaign**

Not market stats or technical job logs.

---

## Required dashboard changes

### Hero headline

Use:

Create Luxury Property Campaigns in Minutes

Subtitle:

Turn listings, photos and videos into AI-powered marketing campaigns, presenter reels, property walkthroughs and social media content designed to help agents win more listings.

Primary CTA:

Generate Property Campaign

Route:

`/jobs/new`

---

## Quick launch cards

Add or keep these actions near the top:

- Property URL → `/jobs/new`
- Upload Photos → `/jobs/new`
- Upload Video → `/jobs/new`
- Teleprompter → `/teleprompter`

---

## Stats wording

Keep existing stats data sources where possible.

Change customer-facing labels:

- Videos Completed → Campaigns Created
- Scripts Generated → Properties Processed
- Hours Saved → Marketing Hours Saved
- Failed → keep in V1 for safety OR Estimated Reach in V2

---

## Recent Jobs wording

Change:

Recent Jobs

to:

Recent Campaigns

Change:

No videos yet

to:

No campaigns yet

Change:

Generate Your First Video

to:

Generate Your First Campaign

Do not change job URLs, IDs, status badges, or the job detail route.

---

## Market brief

Do not delete it.

Move `<MarketBriefCard />` below `<SampleVideos />`.

Rename the visible title:

AU Market Brief

to:

AU Market Intelligence

Keep all hooks and refresh logic untouched.

---

## Presenter studio

Add visual card:

AI Presenter Studio Ready

Presenters:

- Mia — Luxury listings
- Oliver — Corporate premium
- Liam — Confident sales
- Sophie — Lifestyle reels

This is visual only unless presenter selection already exists.

---

## Marketing value card

Add visual card:

Marketing Value Generated

- Script Creation: $50
- Voiceover: $75
- Video Production: $250
- Social Package: $150

Estimated Value Today:

$525

Optional:

`completed campaigns * 525`

This is only a marketing/value display. Do not change billing.

---

## Do not touch

Do not modify:

- scraping logic
- script generation
- voice generation
- HeyGen
- Shotstack
- OpenAI
- ElevenLabs
- database schema
- API client hooks
- authentication
- Stripe
- `/jobs/new`
- job detail page
- real 5-stage pipeline timeline
- final video render logic

---

## Separate bug to fix later

The repeated same-video issue appears separate from dashboard design.

Likely issue:

- HeyGen returns a `video_id`, not a playable MP4 URL.
- Shotstack returns a render ID, not the finished MP4 URL.
- The app may be falling back to a demo/sample MP4.

Check separately:

- `triggerPresenterVideo()`
- `renderFinalReel()`
- `finalVideoUrl`
- job completion handler

Fixing that is backend/pipeline work, not dashboard cosmetic work.
