import React, { useState } from "react";
import { useGetJobStats, useGetMarketBrief, useRefreshMarketBrief, getGetMarketBriefQueryKey } from "@workspace/api-client-react";
import { Link } from "wouter";
import { FileText, CheckCircle2, XCircle, ArrowRight, Play, ChevronDown, Clock, TrendingUp, TrendingDown, Minus, RefreshCw, MapPin, MessageSquare, BarChart2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import buildKitImage from "@assets/LensFlow-The-Build-Kit-every-tool-you-need_1780215479239.png";
import { useAuth } from "@workspace/replit-auth-web";
import { useQueryClient } from "@tanstack/react-query";

function getGreeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

export default function Dashboard() {
  const { data: stats, isLoading } = useGetJobStats();
  const { user } = useAuth();
  const firstName = user?.firstName ?? user?.email?.split("@")[0] ?? null;

  if (isLoading) {
    return <div className="space-y-6 animate-pulse">
      <div className="h-8 w-48 bg-muted rounded"></div>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map(i => <div key={i} className="h-24 bg-muted rounded"></div>)}
      </div>
      <div className="h-64 bg-muted rounded mt-8"></div>
    </div>;
  }

  const completed = stats?.complete ?? 0;
  const processed = stats?.scriptsGenerated ?? 0;
  const hoursSaved = stats?.timeSavedHours ?? 0;
  const estimatedReach = completed > 0 ? completed * 2400 : 0;

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="relative overflow-hidden rounded-2xl border border-primary/20 bg-gradient-to-br from-black via-zinc-950 to-black p-6 md:p-8">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(212,175,55,0.18),transparent_42%)]" />
        <div className="absolute -left-24 -bottom-24 w-72 h-72 rounded-full bg-primary/5 blur-3xl" />

        <div className="relative z-10 grid grid-cols-1 xl:grid-cols-[1.5fr_0.8fr] gap-8 items-end">
          <div>
            <p className="text-sm text-primary font-mono uppercase tracking-[0.25em] mb-3">
              {firstName ? `${getGreeting()}, ${firstName}` : "Welcome to LensFlow"}
            </p>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-primary/30 bg-primary/10 text-primary text-xs font-mono uppercase tracking-widest mb-4">
              LensFlow AI Marketing Engine
            </div>
            <h1 className="text-3xl md:text-5xl font-bold tracking-tight mb-4">
              Create Luxury Property Campaigns in Minutes
            </h1>
            <p className="text-muted-foreground max-w-3xl text-base md:text-lg leading-relaxed">
              Turn listings, photos and videos into AI-powered marketing campaigns, presenter reels,
              property walkthroughs and social media content designed to help agents win more listings.
            </p>
          </div>

          <div className="rounded-2xl border border-primary/20 bg-card/70 p-5">
            <div className="text-xs font-mono uppercase tracking-widest text-muted-foreground mb-3">Quick Launch</div>
            <Link
              href="/jobs/new"
              className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-primary text-primary-foreground font-mono font-semibold hover:bg-primary/90 transition-colors shadow-lg shadow-primary/20 mb-3"
            >
              Generate Property Campaign <ArrowRight className="w-4 h-4" />
            </Link>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <Link href="/jobs/new" className="rounded-lg border border-border bg-background/60 p-3 hover:border-primary/50 transition-colors">
                <div className="text-xl mb-1">🏡</div>
                <div className="font-semibold">Property URL</div>
              </Link>
              <Link href="/jobs/new" className="rounded-lg border border-border bg-background/60 p-3 hover:border-primary/50 transition-colors">
                <div className="text-xl mb-1">📸</div>
                <div className="font-semibold">Photos</div>
              </Link>
              <Link href="/jobs/new" className="rounded-lg border border-border bg-background/60 p-3 hover:border-primary/50 transition-colors">
                <div className="text-xl mb-1">🎥</div>
                <div className="font-semibold">Video</div>
              </Link>
              <Link href="/teleprompter" className="rounded-lg border border-border bg-background/60 p-3 hover:border-primary/50 transition-colors">
                <div className="text-xl mb-1">🎤</div>
                <div className="font-semibold">Teleprompter</div>
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="Campaigns Created" value={completed} icon={CheckCircle2} color="text-primary" />
        <StatCard title="Properties Processed" value={processed} icon={FileText} color="text-blue-400" />
        <StatCard
          title="Marketing Hours Saved"
          value={hoursSaved}
          icon={Clock}
          color="text-emerald-400"
          suffix="h"
          tooltip="Estimated vs. manual filming & editing (~4 hrs/video)"
        />
        <StatCard title="Estimated Reach" value={estimatedReach} icon={TrendingUp} color="text-amber-400" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <PresenterStudioCard />
        <MarketingValueCard completed={completed} />
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Recent Campaigns</h2>
          <div className="flex items-center gap-4">
            <Link href="/jobs" className="text-xs text-muted-foreground font-mono hover:text-primary transition-colors">
              View all
            </Link>
            <Link href="/jobs/new" className="text-sm text-primary hover:underline font-mono flex items-center gap-1">
              Start New <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        <div className="border border-border rounded-lg bg-card overflow-hidden">
          {stats?.recentJobs?.length === 0 ? (
            <div className="py-14 px-8 flex flex-col items-center justify-center text-center space-y-5">
              <div className="w-14 h-14 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center">
                <Play className="w-6 h-6 text-primary ml-0.5" />
              </div>
              <div className="space-y-1.5">
                <p className="font-semibold text-foreground">No campaigns yet</p>
                <p className="text-sm text-muted-foreground max-w-xs">
                  Paste a property listing URL and LensFlow will automatically write the script, record the voiceover, and render a presenter video.
                </p>
              </div>
              <Link
                href="/jobs/new"
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-primary text-primary-foreground rounded text-sm font-mono font-medium hover:bg-primary/90 transition-colors"
              >
                Generate Your First Campaign <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          ) : (
            <div className="divide-y divide-border">
              {stats?.recentJobs?.map((job) => (
                <Link 
                  key={job.id} 
                  href={`/jobs/${job.id}`}
                  className="flex items-center justify-between p-4 hover:bg-secondary/50 transition-colors group"
                >
                  <div className="flex flex-col gap-1 overflow-hidden pr-4">
                    <div className="font-medium truncate">{job.listingTitle || job.listingUrl}</div>
                    <div className="text-xs text-muted-foreground font-mono flex items-center gap-2">
                      <span>ID: {job.id.slice(0, 8)}</span>
                      <span>•</span>
                      <span>{formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 shrink-0">
                    <JobStatusBadge status={job.status} />
                    <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Example Videos */}
      <SampleVideos />

      <MarketBriefCard />

      <RoadmapCard />
    </div>
  );
}

function PresenterStudioCard() {
  const presenters = [
    { name: "Mia", style: "Luxury listings" },
    { name: "Oliver", style: "Corporate premium" },
    { name: "Liam", style: "Confident sales" },
    { name: "Sophie", style: "Lifestyle reels" },
  ];

  return (
    <div className="border border-border rounded-xl bg-card p-5 overflow-hidden relative">
      <div className="absolute -right-10 -top-10 w-40 h-40 rounded-full bg-primary/10 blur-3xl" />
      <div className="relative z-10">
        <div className="flex items-center gap-2 text-sm font-mono uppercase tracking-wider text-muted-foreground mb-3">
          <CheckCircle2 className="w-4 h-4 text-primary" />
          AI Presenter Studio Ready
        </div>
        <h3 className="text-2xl font-bold mb-2">Mia, Oliver, Liam & Sophie are ready</h3>
        <p className="text-sm text-muted-foreground leading-relaxed max-w-md mb-4">
          Choose the right presenter style for luxury listings, vendor updates, agent branding,
          property walkthroughs and social reels.
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {presenters.map((presenter) => (
            <div key={presenter.name} className="rounded-lg border border-border bg-background/60 px-3 py-2 hover:border-primary/40 transition-colors">
              <div className="text-xs font-mono text-primary uppercase tracking-widest">{presenter.name}</div>
              <div className="text-[10px] text-muted-foreground mt-0.5">{presenter.style}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function MarketingValueCard({ completed }: { completed: number }) {
  const total = completed > 0 ? completed * 525 : 525;

  return (
    <div className="border border-border rounded-xl bg-card p-5">
      <div className="flex items-center gap-2 text-sm font-mono uppercase tracking-wider text-muted-foreground mb-4">
        <TrendingUp className="w-4 h-4 text-primary" />
        Marketing Value Generated
      </div>

      <div className="grid grid-cols-2 gap-3 text-sm mb-5">
        <div className="flex justify-between border-b border-border pb-2">
          <span className="text-muted-foreground">Script Creation</span>
          <span className="font-mono">$50</span>
        </div>
        <div className="flex justify-between border-b border-border pb-2">
          <span className="text-muted-foreground">Voiceover</span>
          <span className="font-mono">$75</span>
        </div>
        <div className="flex justify-between border-b border-border pb-2">
          <span className="text-muted-foreground">Video Production</span>
          <span className="font-mono">$250</span>
        </div>
        <div className="flex justify-between border-b border-border pb-2">
          <span className="text-muted-foreground">Social Package</span>
          <span className="font-mono">$150</span>
        </div>
      </div>

      <div className="flex items-end justify-between">
        <div>
          <p className="text-xs text-muted-foreground font-mono uppercase tracking-wider">Estimated value today</p>
          <p className="text-3xl font-bold font-mono text-primary">${total.toLocaleString()}</p>
        </div>
        <p className="text-xs text-muted-foreground max-w-[180px] text-right">
          Shows agents the value LensFlow creates beyond a single video.
        </p>
      </div>
    </div>
  );
}

function TrendIcon({ trend }: { trend: string }) {
  if (trend === "up") return <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />;
  if (trend === "down") return <TrendingDown className="w-3.5 h-3.5 text-rose-400" />;
  return <Minus className="w-3.5 h-3.5 text-muted-foreground" />;
}

function MarketBriefCard() {
  const queryClient = useQueryClient();
  const { data: brief, isLoading, isError } = useGetMarketBrief();
  const refresh = useRefreshMarketBrief();
  const [refreshing, setRefreshing] = useState(false);

  async function handleRefresh() {
    setRefreshing(true);
    await refresh.mutateAsync();
    queryClient.invalidateQueries({ queryKey: getGetMarketBriefQueryKey() });
    setRefreshing(false);
  }

  const updatedAgo = brief?.generatedAt
    ? formatDistanceToNow(new Date(brief.generatedAt), { addSuffix: true })
    : null;

  return (
    <div className="border border-border rounded-lg bg-card overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border">
        <div className="flex items-center gap-2.5">
          <BarChart2 className="w-4 h-4 text-primary" />
          <span className="text-sm font-mono font-medium uppercase tracking-wider">
            AU Market Intelligence
          </span>
          {updatedAgo && (
            <span className="text-[10px] font-mono text-muted-foreground border border-border px-1.5 py-0.5 rounded">
              {updatedAgo}
            </span>
          )}
        </div>
        <button
          type="button"
          onClick={handleRefresh}
          disabled={refreshing || isLoading}
          className="p-1.5 rounded hover:bg-secondary transition-colors disabled:opacity-50"
          title="Refresh market brief"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-muted-foreground ${refreshing ? "animate-spin" : ""}`} />
        </button>
      </div>

      {isLoading ? (
        <div className="p-6 space-y-3 animate-pulse">
          <div className="h-5 w-3/4 bg-muted rounded" />
          <div className="h-3 w-full bg-muted rounded" />
          <div className="h-3 w-5/6 bg-muted rounded" />
          <div className="grid grid-cols-4 gap-3 mt-4">
            {[1,2,3,4].map(i => <div key={i} className="h-14 bg-muted rounded" />)}
          </div>
        </div>
      ) : isError ? (
        <div className="p-6 text-center text-sm text-muted-foreground">
          Could not load market brief. <button type="button" onClick={handleRefresh} className="text-primary underline">Try again</button>
        </div>
      ) : brief ? (
        <div className="p-4 space-y-4">
          {/* Headline */}
          <p className="text-base font-semibold text-foreground leading-snug">{brief.headline}</p>

          {/* Key Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {brief.keyStats.map((stat) => (
              <div key={stat.label} className="bg-background border border-border rounded-lg p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-mono text-muted-foreground uppercase tracking-wide truncate pr-1">
                    {stat.label}
                  </span>
                  <TrendIcon trend={stat.trend} />
                </div>
                <p className="text-lg font-bold font-mono text-foreground">{stat.value}</p>
              </div>
            ))}
          </div>

          {/* Snapshot */}
          <p className="text-sm text-muted-foreground leading-relaxed">{brief.snapshot}</p>

          {/* Talking Points */}
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 text-[10px] font-mono text-muted-foreground uppercase tracking-wider mb-2">
              <MessageSquare className="w-3 h-3" /> Agent Talking Points
            </div>
            {brief.talkingPoints.map((point, i) => (
              <div key={i} className="flex items-start gap-2.5 text-sm">
                <span className="mt-0.5 w-4 h-4 rounded-full bg-primary/15 text-primary text-[10px] font-bold flex items-center justify-center shrink-0">
                  {i + 1}
                </span>
                <span className="text-foreground/80 leading-relaxed">{point}</span>
              </div>
            ))}
          </div>

          {/* Hot Markets + Outlook */}
          <div className="flex flex-col sm:flex-row gap-3 pt-1 border-t border-border">
            <div className="flex-1">
              <div className="flex items-center gap-1.5 text-[10px] font-mono text-muted-foreground uppercase tracking-wider mb-2">
                <MapPin className="w-3 h-3" /> Hot Markets
              </div>
              <div className="flex flex-wrap gap-1.5">
                {brief.hotMarkets.map((market) => (
                  <span
                    key={market}
                    className="px-2 py-0.5 bg-primary/10 text-primary border border-primary/20 rounded-full text-[11px] font-mono"
                  >
                    {market}
                  </span>
                ))}
              </div>
            </div>
            <div className="sm:max-w-xs">
              <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-wider mb-1">60–90 Day Outlook</div>
              <p className="text-xs text-foreground/70 leading-relaxed italic">{brief.outlook}</p>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

const SAMPLE_VIDEOS = [
  { src: "/videos/oliver-featured.mp4", label: "Oliver · Williamstown, VIC", featured: true },
  { src: "/videos/sample-v1.mp4", label: "Mia · Mosman, NSW", featured: false },
  { src: "/videos/sample-v2.mp4", label: "Oliver · South Yarra, VIC", featured: false },
  { src: "/videos/sample-v3.mp4", label: "Sophie · Brighton, VIC", featured: false },
  { src: "/videos/sample-v4.mp4", label: "Mia · Bondi, NSW", featured: false },
  { src: "/videos/sample-v5.mp4", label: "Sophie · Toorak, VIC", featured: false },
];

function SampleVideos() {
  const [expanded, setExpanded] = useState(false);
  const featured = SAMPLE_VIDEOS[0];
  const grid = SAMPLE_VIDEOS.slice(1);

  return (
    <div className="border border-border rounded-lg bg-card overflow-hidden">
      <button
        type="button"
        onClick={() => setExpanded((o) => !o)}
        className="w-full flex items-center justify-between p-4 hover:bg-secondary/30 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-primary" />
          <span className="text-sm font-mono font-medium uppercase tracking-wider">Example Output Videos</span>
          <span className="text-[10px] font-mono text-muted-foreground border border-border px-1.5 py-0.5 rounded">
            {SAMPLE_VIDEOS.length} reels
          </span>
        </div>
        <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${expanded ? "rotate-180" : ""}`} />
      </button>
      {expanded && (
        <div className="border-t border-border p-4 space-y-3">
          <p className="text-xs text-muted-foreground font-mono mb-4">Real LensFlow output — hover to preview, click to play with sound.</p>
          {/* Featured */}
          <div className="relative rounded-xl overflow-hidden border border-white/10 aspect-video bg-black group">
            <video
              src={featured.src}
              autoPlay
              muted
              loop
              playsInline
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent pointer-events-none" />
            <div className="absolute bottom-3 left-3 flex items-center gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse" />
              <span className="text-[10px] font-mono text-white/80 uppercase tracking-widest">{featured.label}</span>
            </div>
            <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded bg-primary/90 text-[9px] font-mono text-primary-foreground uppercase tracking-widest">
              AI Generated
            </div>
          </div>
          {/* Grid */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
            {grid.map((v, i) => (
              <div
                key={i}
                className="relative rounded-lg overflow-hidden border border-white/8 aspect-video bg-black group cursor-pointer"
              >
                <video
                  src={v.src}
                  muted
                  loop
                  playsInline
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  onMouseEnter={(e) => (e.currentTarget as HTMLVideoElement).play()}
                  onMouseLeave={(e) => { (e.currentTarget as HTMLVideoElement).pause(); (e.currentTarget as HTMLVideoElement).currentTime = 0; }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                <div className="absolute bottom-1.5 left-1.5 right-1.5 flex items-center gap-1">
                  <span className="text-[8px] font-mono text-white/60 uppercase tracking-widest truncate">{v.label}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function RoadmapCard() {
  const [open, setOpen] = useState(false);
  return (
    <div className="border border-border rounded-lg bg-card overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center justify-between p-4 hover:bg-secondary/30 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
          <span className="text-sm font-mono font-medium uppercase tracking-wider">Production Roadmap</span>
          <span className="text-[10px] font-mono text-muted-foreground border border-border px-1.5 py-0.5 rounded">URL → VIDEO ENGINE</span>
        </div>
        <ChevronDown className={`w-4 h-4 text-muted-foreground transition-transform ${open ? "rotate-180" : ""}`} />
      </button>
      {open && (
        <div className="border-t border-border">
          <img
            src={buildKitImage}
            alt="LensFlow full pipeline architecture — vendor map from URL scrape to MP4 delivery"
            className="w-full"
          />
          <div className="p-4 flex items-center gap-2 text-xs text-muted-foreground font-mono border-t border-border">
            <span className="w-1.5 h-1.5 rounded-full bg-primary" />
            Build window 4–8 weeks · ~$2.54 cost/video · $3.95/vid margin at 20 vids/mo
          </div>
        </div>
      )}
    </div>
  );
}

function StatCard({ title, value, icon: Icon, color, suffix, tooltip }: {
  title: string;
  value: number;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  suffix?: string;
  tooltip?: string;
}) {
  return (
    <div className="bg-card border border-border p-4 rounded-lg flex flex-col gap-2 relative overflow-hidden group" title={tooltip}>
      <div className="absolute -right-4 -top-4 opacity-5 group-hover:scale-110 transition-transform duration-500">
        <Icon className={`w-24 h-24 ${color}`} />
      </div>
      <div className="flex items-center gap-2 text-muted-foreground">
        <Icon className={`w-4 h-4 ${color}`} />
        <span className="text-xs font-mono uppercase tracking-wider">{title}</span>
      </div>
      <div className="text-3xl font-bold font-mono">
        {value}{suffix && <span className="text-xl ml-0.5 text-muted-foreground">{suffix}</span>}
      </div>
    </div>
  );
}

export function JobStatusBadge({ status }: { status: string }) {
  const colors = {
    queued: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
    processing: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    complete: "bg-primary/10 text-primary border-primary/20",
    failed: "bg-destructive/10 text-destructive border-destructive/20"
  };

  return (
    <span className={`px-2.5 py-0.5 rounded-full text-[10px] uppercase tracking-wider font-mono border ${colors[status as keyof typeof colors] || colors.queued}`}>
      {status}
    </span>
  );
}
